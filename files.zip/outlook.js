import { ConfidentialClientApplication } from '@azure/msal-node'

const msalConfig = {
  auth: {
    clientId: process.env.AZURE_CLIENT_ID,
    clientSecret: process.env.AZURE_CLIENT_SECRET,
    authority: `https://login.microsoftonline.com/${process.env.AZURE_TENANT_ID}`,
  },
}

export async function getAccessToken() {
  const cca = new ConfidentialClientApplication(msalConfig)
  const result = await cca.acquireTokenByClientCredential({
    scopes: ['https://graph.microsoft.com/.default'],
  })
  return result.accessToken
}

export async function getEmails(token, count = 20) {
  const res = await fetch(
    `https://graph.microsoft.com/v1.0/users/${process.env.OUTLOOK_EMAIL}/mailFolders/inbox/messages?$top=${count}&$orderby=receivedDateTime desc&$select=id,subject,from,receivedDateTime,bodyPreview,body,isRead`,
    { headers: { Authorization: `Bearer ${token}` } }
  )
  const data = await res.json()
  return data.value || []
}

export async function sendEmail(token, to, subject, body, replyToMessageId = null) {
  const endpoint = replyToMessageId
    ? `https://graph.microsoft.com/v1.0/users/${process.env.OUTLOOK_EMAIL}/messages/${replyToMessageId}/reply`
    : `https://graph.microsoft.com/v1.0/users/${process.env.OUTLOOK_EMAIL}/sendMail`

  const payload = replyToMessageId
    ? { comment: body }
    : {
        message: {
          subject,
          body: { contentType: 'Text', content: body },
          toRecipients: [{ emailAddress: { address: to } }],
        },
      }

  await fetch(endpoint, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  })
}
