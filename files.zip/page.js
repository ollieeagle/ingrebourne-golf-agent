'use client'
import { useState, useEffect } from 'react'

const TABS = ['Inbox', 'Content', 'Settings']

function UrgencyBadge({ text }) {
  const lower = (text || '').toLowerCase()
  const map = {
    urgent: { bg: '#fee2e2', color: '#991b1b', label: 'Urgent' },
    high: { bg: '#fef3c7', color: '#92400e', label: 'High' },
    medium: { bg: '#dbeafe', color: '#1e40af', label: 'Medium' },
    low: { bg: '#d1fae5', color: '#065f46', label: 'Low' },
  }
  const match = Object.keys(map).find(k => lower.includes(k))
  const style = match ? map[match] : map.low
  return (
    <span style={{
      background: style.bg, color: style.color,
      fontSize: 10, fontWeight: 600, padding: '2px 8px',
      borderRadius: 20, letterSpacing: '0.04em'
    }}>{style.label}</span>
  )
}

function EmailCard({ email, onSelect, selected }) {
  const isUnread = !email.isRead
  return (
    <div onClick={() => onSelect(email)} style={{
      background: selected ? '#f0fdf4' : '#fff',
      border: `1px solid ${selected ? '#16a34a' : '#e5e7eb'}`,
      borderRadius: 14, padding: '14px 16px', marginBottom: 10,
      cursor: 'pointer', transition: 'all 0.15s'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
        <span style={{ fontSize: 13, fontWeight: isUnread ? 700 : 500, color: '#111' }}>
          {isUnread && <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#16a34a', display: 'inline-block', marginRight: 6 }} />}
          {email.from?.emailAddress?.name || email.from?.emailAddress?.address}
        </span>
        <span style={{ fontSize: 11, color: '#9ca3af' }}>
          {new Date(email.receivedDateTime).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
        </span>
      </div>
      <div style={{ fontSize: 13, fontWeight: isUnread ? 600 : 400, color: '#374151', marginBottom: 3 }}>{email.subject}</div>
      <div style={{ fontSize: 12, color: '#9ca3af', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{email.bodyPreview}</div>
    </div>
  )
}

function EmailDetail({ email, onClose }) {
  const [summary, setSummary] = useState('')
  const [draft, setDraft] = useState('')
  const [loading, setLoading] = useState(false)
  const [draftLoading, setDraftLoading] = useState(false)
  const [sent, setSent] = useState(false)
  const [instructions, setInstructions] = useState('')
  const [tab, setTab] = useState('summary')

  useEffect(() => {
    summarise()
  }, [email])

  async function summarise() {
    setLoading(true)
    setSummary('')
    const res = await fetch('/api/summarise', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subject: email.subject,
        from: email.from?.emailAddress?.address,
        body: email.body?.content || email.bodyPreview
      })
    })
    const data = await res.json()
    setSummary(data.summary || 'Could not summarise.')
    setLoading(false)
  }

  async function generateDraft() {
    setDraftLoading(true)
    setDraft('')
    setTab('reply')
    const res = await fetch('/api/reply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subject: email.subject,
        from: email.from?.emailAddress?.address,
        body: email.body?.content || email.bodyPreview,
        messageId: email.id,
        autoSend: false,
        customInstructions: instructions
      })
    })
    const data = await res.json()
    setDraft(data.draft || '')
    setDraftLoading(false)
  }

  async function sendDraft() {
    const res = await fetch('/api/reply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subject: email.subject,
        from: email.from?.emailAddress?.address,
        body: draft,
        messageId: email.id,
        autoSend: true
      })
    })
    const data = await res.json()
    if (data.sent) setSent(true)
  }

  return (
    <div style={{ position: 'fixed', inset: 0, background: '#f9fafb', zIndex: 100, overflowY: 'auto', padding: '16px 16px 100px' }}>
      <button onClick={onClose} style={{
        background: 'none', border: 'none', fontSize: 15, color: '#16a34a',
        fontWeight: 600, cursor: 'pointer', marginBottom: 16, padding: 0
      }}>← Back</button>

      <div style={{ background: '#fff', borderRadius: 16, padding: 16, marginBottom: 12, border: '1px solid #e5e7eb' }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: '#111', marginBottom: 4 }}>{email.subject}</div>
        <div style={{ fontSize: 12, color: '#6b7280' }}>From: {email.from?.emailAddress?.address}</div>
        <div style={{ fontSize: 12, color: '#9ca3af' }}>{new Date(email.receivedDateTime).toLocaleString('en-GB')}</div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {['summary', 'reply', 'original'].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            flex: 1, padding: '9px 0', borderRadius: 10, border: 'none',
            background: tab === t ? '#16a34a' : '#e5e7eb',
            color: tab === t ? '#fff' : '#374151',
            fontSize: 13, fontWeight: 600, cursor: 'pointer', textTransform: 'capitalize'
          }}>{t}</button>
        ))}
      </div>

      {tab === 'summary' && (
        <div style={{ background: '#fff', borderRadius: 16, padding: 16, border: '1px solid #e5e7eb' }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: '#16a34a', marginBottom: 10, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            ✦ AI Summary
          </div>
          {loading ? (
            <div style={{ color: '#9ca3af', fontSize: 14 }}>Analysing email...</div>
          ) : (
            <div style={{ fontSize: 14, color: '#374151', lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{summary}</div>
          )}
          <button onClick={generateDraft} style={{
            marginTop: 16, width: '100%', padding: '12px 0', borderRadius: 12,
            background: '#16a34a', color: '#fff', border: 'none',
            fontSize: 14, fontWeight: 700, cursor: 'pointer'
          }}>Draft a Reply</button>
        </div>
      )}

      {tab === 'reply' && (
        <div style={{ background: '#fff', borderRadius: 16, padding: 16, border: '1px solid #e5e7eb' }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: '#16a34a', marginBottom: 10, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Draft Reply
          </div>
          <input
            placeholder="Any special instructions? (optional)"
            value={instructions}
            onChange={e => setInstructions(e.target.value)}
            style={{
              width: '100%', padding: '10px 12px', borderRadius: 10,
              border: '1px solid #e5e7eb', fontSize: 13, marginBottom: 10,
              boxSizing: 'border-box', outline: 'none'
            }}
          />
          {draftLoading && <div style={{ color: '#9ca3af', fontSize: 14, marginBottom: 10 }}>Writing reply...</div>}
          {draft && (
            <>
              <textarea
                value={draft}
                onChange={e => setDraft(e.target.value)}
                rows={10}
                style={{
                  width: '100%', padding: '12px', borderRadius: 10,
                  border: '1px solid #e5e7eb', fontSize: 13, lineHeight: 1.6,
                  boxSizing: 'border-box', outline: 'none', resize: 'none'
                }}
              />
              {sent ? (
                <div style={{ textAlign: 'center', color: '#16a34a', fontWeight: 700, marginTop: 12 }}>✓ Sent successfully</div>
              ) : (
                <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                  <button onClick={generateDraft} style={{
                    flex: 1, padding: '12px 0', borderRadius: 12,
                    background: '#f3f4f6', color: '#374151', border: 'none',
                    fontSize: 13, fontWeight: 600, cursor: 'pointer'
                  }}>Regenerate</button>
                  <button onClick={sendDraft} style={{
                    flex: 2, padding: '12px 0', borderRadius: 12,
                    background: '#16a34a', color: '#fff', border: 'none',
                    fontSize: 14, fontWeight: 700, cursor: 'pointer'
                  }}>Send Reply</button>
                </div>
              )}
            </>
          )}
          {!draft && !draftLoading && (
            <button onClick={generateDraft} style={{
              width: '100%', padding: '12px 0', borderRadius: 12,
              background: '#16a34a', color: '#fff', border: 'none',
              fontSize: 14, fontWeight: 700, cursor: 'pointer'
            }}>Generate Draft</button>
          )}
        </div>
      )}

      {tab === 'original' && (
        <div style={{ background: '#fff', borderRadius: 16, padding: 16, border: '1px solid #e5e7eb' }}>
          <div style={{ fontSize: 14, color: '#374151', lineHeight: 1.7 }}
            dangerouslySetInnerHTML={{ __html: email.body?.content || email.bodyPreview }} />
        </div>
      )}
    </div>
  )
}

function ContentTab() {
  const [request, setRequest] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)

  async function generate() {
    if (!request.trim()) return
    setLoading(true)
    setResult(null)
    const res = await fetch('/api/content', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ request, type: 'social media post' })
    })
    const data = await res.json()
    setResult(data)
    setLoading(false)
  }

  const examples = [
    'Instagram post for a sunny weekend round',
    'Facebook post promoting our society day packages',
    'Post celebrating a member hole-in-one',
    'Promoting our new buggy fleet',
  ]

  return (
    <div style={{ padding: '16px 16px 100px' }}>
      <div style={{ fontSize: 18, fontWeight: 700, color: '#111', marginBottom: 4 }}>Content Creator</div>
      <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 20 }}>Generate social media posts and marketing content</div>

      <textarea
        placeholder="What content do you need? e.g. Instagram post for a sunny weekend at the club"
        value={request}
        onChange={e => setRequest(e.target.value)}
        rows={3}
        style={{
          width: '100%', padding: '12px', borderRadius: 12,
          border: '1px solid #e5e7eb', fontSize: 14, lineHeight: 1.6,
          boxSizing: 'border-box', outline: 'none', resize: 'none', marginBottom: 10
        }}
      />

      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 12, color: '#9ca3af', marginBottom: 8 }}>Quick examples:</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {examples.map(e => (
            <button key={e} onClick={() => setRequest(e)} style={{
              fontSize: 12, padding: '6px 12px', borderRadius: 20,
              background: '#f3f4f6', border: '1px solid #e5e7eb',
              color: '#374151', cursor: 'pointer'
            }}>{e}</button>
          ))}
        </div>
      </div>

      <button onClick={generate} disabled={loading || !request.trim()} style={{
        width: '100%', padding: '14px 0', borderRadius: 12,
        background: loading ? '#9ca3af' : '#16a34a', color: '#fff',
        border: 'none', fontSize: 15, fontWeight: 700, cursor: loading ? 'not-allowed' : 'pointer',
        marginBottom: 20
      }}>{loading ? 'Creating...' : 'Generate Content'}</button>

      {result && (
        <div style={{ background: '#fff', borderRadius: 16, border: '1px solid #e5e7eb', overflow: 'hidden' }}>
          <div style={{ background: '#16a34a', padding: '12px 16px' }}>
            <span style={{ color: '#fff', fontSize: 13, fontWeight: 700 }}>
              {result.platform || 'Social Media'} Content
            </span>
          </div>
          <div style={{ padding: 16 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#6b7280', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Caption</div>
            <div style={{ fontSize: 14, color: '#111', lineHeight: 1.7, marginBottom: 16, whiteSpace: 'pre-wrap' }}>{result.caption}</div>

            {result.hashtags?.length > 0 && (
              <>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#6b7280', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Hashtags</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 16 }}>
                  {result.hashtags.map(h => (
                    <span key={h} style={{ background: '#dcfce7', color: '#166534', fontSize: 12, padding: '4px 10px', borderRadius: 20 }}>
                      {h.startsWith('#') ? h : `#${h}`}
                    </span>
                  ))}
                </div>
              </>
            )}

            {result.imagePrompt && (
              <>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#6b7280', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Image Prompt</div>
                <div style={{
                  background: '#f8fafc', borderRadius: 10, padding: 12,
                  fontSize: 13, color: '#475569', lineHeight: 1.6,
                  border: '1px dashed #cbd5e1'
                }}>
                  <div style={{ fontSize: 11, color: '#94a3b8', marginBottom: 4 }}>Paste this into Midjourney or DALL-E:</div>
                  {result.imagePrompt}
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

function SettingsTab() {
  return (
    <div style={{ padding: '16px 16px 100px' }}>
      <div style={{ fontSize: 18, fontWeight: 700, color: '#111', marginBottom: 4 }}>Settings</div>
      <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 20 }}>Manage your AI assistant</div>

      {[
        { label: 'Connected Account', value: process.env.NEXT_PUBLIC_OUTLOOK_EMAIL || 'golf@ingrebourne.co.uk', icon: '📧' },
        { label: 'AI Model', value: 'Claude Sonnet (Anthropic)', icon: '🧠' },
        { label: 'Reply Mode', value: 'Draft & Approve', icon: '✍️' },
        { label: 'Club', value: 'Ingrebourne Links Golf & Country Club', icon: '⛳' },
      ].map(item => (
        <div key={item.label} style={{
          background: '#fff', borderRadius: 14, padding: '14px 16px',
          border: '1px solid #e5e7eb', marginBottom: 10,
          display: 'flex', alignItems: 'center', gap: 12
        }}>
          <span style={{ fontSize: 20 }}>{item.icon}</span>
          <div>
            <div style={{ fontSize: 11, color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>{item.label}</div>
            <div style={{ fontSize: 14, color: '#111', fontWeight: 500 }}>{item.value}</div>
          </div>
        </div>
      ))}

      <div style={{ marginTop: 24, background: '#f0fdf4', borderRadius: 14, padding: 16, border: '1px solid #bbf7d0' }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: '#166534', marginBottom: 6 }}>Built by PreGame Industries</div>
        <div style={{ fontSize: 12, color: '#4ade80' }}>AI-powered business systems for modern operations</div>
      </div>
    </div>
  )
}

export default function App() {
  const [tab, setTab] = useState('Inbox')
  const [emails, setEmails] = useState([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState(null)
  const [loggedIn, setLoggedIn] = useState(false)
  const [password, setPassword] = useState('')
  const [loginError, setLoginError] = useState('')

  useEffect(() => {
    const auth = sessionStorage.getItem('golf_auth')
    if (auth === 'true') setLoggedIn(true)
  }, [])

  useEffect(() => {
    if (loggedIn && tab === 'Inbox') fetchEmails()
  }, [loggedIn, tab])

  async function fetchEmails() {
    setLoading(true)
    try {
      const res = await fetch('/api/emails')
      const data = await res.json()
      setEmails(data.emails || [])
    } catch {
      setEmails([])
    }
    setLoading(false)
  }

  function login() {
    if (password === (process.env.NEXT_PUBLIC_APP_PASSWORD || 'ingrebourne2024')) {
      sessionStorage.setItem('golf_auth', 'true')
      setLoggedIn(true)
    } else {
      setLoginError('Incorrect password')
    }
  }

  if (!loggedIn) {
    return (
      <div style={{
        minHeight: '100vh', background: '#f0fdf4',
        display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24
      }}>
        <div style={{ width: '100%', maxWidth: 340 }}>
          <div style={{ textAlign: 'center', marginBottom: 32 }}>
            <div style={{
              width: 64, height: 64, borderRadius: '50%', background: '#16a34a',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 28, margin: '0 auto 16px'
            }}>⛳</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#111' }}>Ingrebourne Links</div>
            <div style={{ fontSize: 14, color: '#6b7280' }}>Golf Operations AI Assistant</div>
          </div>
          <input
            type="password"
            placeholder="Enter password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && login()}
            style={{
              width: '100%', padding: '14px 16px', borderRadius: 12,
              border: '1.5px solid #e5e7eb', fontSize: 15,
              boxSizing: 'border-box', outline: 'none', marginBottom: 10
            }}
          />
          {loginError && <div style={{ color: '#dc2626', fontSize: 13, marginBottom: 10 }}>{loginError}</div>}
          <button onClick={login} style={{
            width: '100%', padding: '14px 0', borderRadius: 12,
            background: '#16a34a', color: '#fff', border: 'none',
            fontSize: 16, fontWeight: 700, cursor: 'pointer'
          }}>Sign In</button>
          <div style={{ textAlign: 'center', marginTop: 20, fontSize: 11, color: '#9ca3af' }}>
            Powered by PreGame Industries
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={{ minHeight: '100vh', background: '#f9fafb', fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif' }}>
      <div style={{
        background: '#fff', padding: '16px 16px 12px',
        borderBottom: '1px solid #e5e7eb', position: 'sticky', top: 0, zIndex: 50
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 36, height: 36, borderRadius: '50%', background: '#16a34a',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 18, flexShrink: 0
          }}>⛳</div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#111' }}>Golf Operations</div>
            <div style={{ fontSize: 11, color: '#9ca3af' }}>Ingrebourne Links · AI Assistant</div>
          </div>
        </div>
      </div>

      {selected && <EmailDetail email={selected} onClose={() => setSelected(null)} />}

      {tab === 'Inbox' && !selected && (
        <div style={{ padding: '16px 16px 100px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 18, fontWeight: 700, color: '#111' }}>Inbox</div>
              <div style={{ fontSize: 13, color: '#6b7280' }}>{emails.length} emails</div>
            </div>
            <button onClick={fetchEmails} style={{
              background: '#f3f4f6', border: 'none', borderRadius: 10,
              padding: '8px 14px', fontSize: 13, fontWeight: 600,
              color: '#374151', cursor: 'pointer'
            }}>Refresh</button>
          </div>
          {loading ? (
            <div style={{ textAlign: 'center', color: '#9ca3af', padding: 40 }}>Loading emails...</div>
          ) : emails.length === 0 ? (
            <div style={{ textAlign: 'center', color: '#9ca3af', padding: 40 }}>No emails found</div>
          ) : (
            emails.map(email => (
              <EmailCard key={email.id} email={email} onSelect={setSelected} selected={selected?.id === email.id} />
            ))
          )}
        </div>
      )}

      {tab === 'Content' && <ContentTab />}
      {tab === 'Settings' && <SettingsTab />}

      <div style={{
        position: 'fixed', bottom: 0, left: 0, right: 0,
        background: '#fff', borderTop: '1px solid #e5e7eb',
        display: 'flex', padding: '10px 0 20px', zIndex: 50
      }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            flex: 1, background: 'none', border: 'none',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
            cursor: 'pointer', padding: '4px 0'
          }}>
            <span style={{ fontSize: 20 }}>
              {t === 'Inbox' ? '📧' : t === 'Content' ? '✍️' : '⚙️'}
            </span>
            <span style={{
              fontSize: 11, fontWeight: 600,
              color: tab === t ? '#16a34a' : '#9ca3af'
            }}>{t}</span>
          </button>
        ))}
      </div>
    </div>
  )
}
