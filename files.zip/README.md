# Ingrebourne Links — Golf Operations AI Assistant
### Built by PreGame Industries

A mobile-first PWA (Progressive Web App) that gives the Golf Operations Manager at Ingrebourne Links an AI-powered assistant to manage emails, draft replies, and create content.

---

## What this app does

- **Reads all Outlook emails** — connected to the golf ops inbox
- **AI summaries** — Claude reads every email and summarises it instantly
- **Draft replies** — Claude writes professional replies, manager approves before sending
- **Content creator** — generates social media posts, captions, hashtags and image prompts
- **Mobile PWA** — installs on iPhone or Android like a real app

---

## Step by Step Setup Guide

### STEP 1 — Get your Claude API Key

1. Go to **console.anthropic.com**
2. Sign up with your email
3. Go to **API Keys** in the left sidebar
4. Click **Create Key** → name it "Ingrebourne Golf Agent"
5. Copy the key — save it somewhere safe (you only see it once)

---

### STEP 2 — Set up Microsoft Outlook Access (Azure Portal)

1. Go to **portal.azure.com** → sign in with a Microsoft account
2. Search for **"App Registrations"** → click **New Registration**
3. Name it: `Ingrebourne Email Agent` → click Register
4. Copy the **Application (Client) ID** — save it
5. Copy the **Directory (Tenant) ID** — save it
6. Go to **Certificates & Secrets** → New Client Secret → add description → copy the **Value** (save it now — it won't show again)
7. Go to **API Permissions** → Add a Permission → Microsoft Graph → Application permissions → add these:
   - `Mail.Read`
   - `Mail.Send`
   - `Mail.ReadWrite`
8. Click **Grant Admin Consent**

---

### STEP 3 — Create Vercel Account

1. Go to **vercel.com** → sign up
2. Connect your **GitHub** account (sign up at github.com if needed — it's free)

---

### STEP 4 — Upload the code to GitHub

1. Go to **github.com** → click **New Repository**
2. Name it: `ingrebourne-golf-agent`
3. Upload all the files from this folder into the repository

---

### STEP 5 — Deploy on Vercel

1. Go to **vercel.com** → click **New Project**
2. Import your GitHub repository
3. Before deploying, go to **Environment Variables** and add these:

| Key | Value |
|-----|-------|
| `ANTHROPIC_API_KEY` | Your Claude API key from Step 1 |
| `AZURE_CLIENT_ID` | From Step 2 |
| `AZURE_CLIENT_SECRET` | From Step 2 |
| `AZURE_TENANT_ID` | From Step 2 |
| `OUTLOOK_EMAIL` | golf@ingrebourne.co.uk |
| `APP_PASSWORD` | Choose a password for your client |

4. Click **Deploy** — Vercel will build and deploy it automatically
5. You'll get a live URL like: `ingrebourne-golf-agent.vercel.app`

---

### STEP 6 — Install on your client's phone as a PWA

**iPhone:**
1. Send the client the Vercel URL
2. Open it in **Safari**
3. Tap the **Share** button (box with arrow)
4. Tap **Add to Home Screen**
5. App appears on home screen like a native app ✅

**Android:**
1. Open the URL in **Chrome**
2. Tap the three dots menu
3. Tap **Add to Home Screen**
4. Done ✅

---

## Costs

| Service | Cost |
|---------|------|
| Vercel hosting | Free (Hobby plan) |
| Claude API | ~£10-30/month depending on email volume |
| Azure (Microsoft) | Free tier covers this usage |

---

## Built by PreGame Industries
AI-powered business systems for modern operations.
