import Anthropic from '@anthropic-ai/sdk'

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const { request, type = 'post' } = req.body

  try {
    const message = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1500,
      system: `You are a marketing and content assistant for Ingrebourne Links Golf & Country Club — a premium golf and country club in Essex, UK.
Create engaging, professional content that reflects the club's prestige and community feel.
For social media, keep it warm, inviting, and aspirational.
Always return a JSON object with these fields:
- caption: the main written content/caption
- hashtags: relevant hashtags as an array
- imagePrompt: a detailed prompt to generate an image for this content using an AI image generator like DALL-E or Midjourney
- platform: suggested platform (Instagram, Facebook, or both)`,
      messages: [
        {
          role: 'user',
          content: `Create ${type} content for: ${request}
Return only valid JSON, no markdown, no explanation.`,
        },
      ],
    })

    const raw = message.content[0].text.replace(/```json|```/g, '').trim()
    const content = JSON.parse(raw)
    res.status(200).json(content)
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to generate content' })
  }
}
