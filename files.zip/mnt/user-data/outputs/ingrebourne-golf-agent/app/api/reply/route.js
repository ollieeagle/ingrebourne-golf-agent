import Anthropic from '@anthropic-ai/sdk'
import { getAccessToken, sendEmail } from '../../../lib/outlook'

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const { subject, from, body, messageId, autoSend = false, customInstructions = '' } = req.body

  try {
    const message = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      system: `You are the Golf Operations Manager at Ingrebourne Links Golf & Country Club.
Write professional, warm, and helpful email replies on behalf of the golf operations team.
Sign off as: Golf Operations Team, Ingrebourne Links Golf & Country Club.
Keep replies concise but friendly. Never make up specific details like prices or availability — leave placeholders like [TIME] or [PRICE] where specific info is needed.`,
      messages: [
        {
          role: 'user',
          content: `Write a professional reply to this email.
${customInstructions ? `Additional instructions: ${customInstructions}` : ''}

Original email:
From: ${from}
Subject: ${subject}
Body: ${body}`,
        },
      ],
    })

    const draft = message.content[0].text

    if (autoSend) {
      const token = await getAccessToken()
      await sendEmail(token, from, `Re: ${subject}`, draft, messageId)
      return res.status(200).json({ draft, sent: true })
    }

    res.status(200).json({ draft, sent: false })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to draft reply' })
  }
}
