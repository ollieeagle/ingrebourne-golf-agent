import Anthropic from '@anthropic-ai/sdk'

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const { subject, from, body } = req.body

  try {
    const message = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      system: `You are an AI assistant for the Golf Operations Manager at Ingrebourne Links Golf & Country Club. 
You help manage emails professionally and efficiently.
Always be concise, professional, and golf-club appropriate in tone.`,
      messages: [
        {
          role: 'user',
          content: `Summarise this email clearly and tell me:
1. What it's about (1 sentence)
2. Who sent it and their likely intent
3. Urgency level: Low / Medium / High / Urgent
4. What action is needed (if any)
5. Key details to remember

From: ${from}
Subject: ${subject}
Body: ${body}`,
        },
      ],
    })

    res.status(200).json({ summary: message.content[0].text })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Failed to summarise email' })
  }
}
